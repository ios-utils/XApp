//
//  NibInstantiable
//  App
//

import UIKit

/**
 A view or object that can be instantiated from a Nib
 */
protocol NibInstantiable {
    
    /// Nib name.
    static var nibName: String { get }
    
    /// Create an instance from the nib
    static func initFromNib() -> Self
    
}

extension UIView: NibInstantiable { /* All UIViews */ }

extension NibInstantiable {
    
    /// Nib name.
    static var nibName: String {
        return String(describing: self)
    }
    
    /// Instantiate a view of the current type at the index.
    static func initFromNib() -> Self {
        guard let object = initFromNib(objectAtIndex: 0) as? Self else {
            fatalError("Nib named \"\(nibName)\" did exist, but the object had a mismatched type \(String(describing: self)).")
        }
        
        return object
    }
    
    /// Instantiate an object at a specific index from the Nib.
    static func initFromNib(objectAtIndex index: Int) -> Any {
        let nib = UINib(nibName: nibName, bundle: nil)
        let objects = nib.instantiate(withOwner: nil, options: nil)
        
        guard objects.indices.contains(index) else {
            fatalError("No object at index \(index) in Nib named: \"\(nibName)\".")
        }
        
        return objects[index]
    }
    
}
