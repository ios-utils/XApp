//
//  CardView
//  App
//

import UIKit

/**
 A UIView that has a small border and shadow.
 */
public class CardView: UIView {
    
    // MARK: - UIView
    
    /// Awake from Nib
    public override func awakeFromNib() {
        super.awakeFromNib()
        
        configureLayerBorder()
        configureLayerShadow()
    }
    
    // MARK: - Implementation
    
    /// Configure shadow
    private func configureLayerShadow() {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.1
        layer.shadowOffset = .zero
        layer.shadowRadius = 5
        
        // Optional: Rasterize
        layer.rasterizationScale = UIScreen.main.scale
        layer.shouldRasterize = true
    }
    
    /// Configure border
    private func configureLayerBorder() {
        layer.borderWidth = 0.5
        layer.borderColor = Colors.ultraGray()?.cgColor
    }
    
}
