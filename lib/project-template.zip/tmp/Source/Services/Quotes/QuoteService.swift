//
//  QuoteService
//  App
//

import Moya

/**
 Quote Service
 */
public enum QuoteService {
    
    /// Get a random quote
    case randomQuote
    
}

extension QuoteService: TargetType {
    
    // MARK: - TargetType
    
    /// Base URL
    public var baseURL: URL {
        return URL(string: "https://api.chew.pro/trbmb")!
    }
    
    /// Path
    public var path: String {
        return ""
    }
    
    /// HTTP Method
    public var method: Method {
        return .get
    }
    
    /// Task
    public var task: Task {
        return .requestPlain
    }
    
    /// Headers
    public var headers: [String: String]? {
        return nil
    }
    
    /// Sample data for a mocked response
    public var sampleData: Data {
        return Data()
    }
    
}
