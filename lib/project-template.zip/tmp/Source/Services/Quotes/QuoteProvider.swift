//
//  QuoteProvider
//  App
//

import Moya
import RxSwift
import RxCocoa
import Moya_ModelMapper

/**
 Quote Provider
 */
public final class QuoteProvider: MoyaProvider<QuoteService> {
    
    /// Get page HTML from title.
    public func getRandomQuote() -> Single<String> {
        return rx.request(.randomQuote)
            .map([String].self)
            .flatMap { .just($0[0]) }
    }
    
    /// Initializer
    /// - Note: Setting an empty default initializer, as otherwise Swinject will
    ///         try to automagically infer all the default MoyaProvider parameters.
    public init() {
        super.init()
    }
    
}
