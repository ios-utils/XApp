//
//  AppCoordinator
//

import UIKit

/**
 Main App Coordinator.
 */
class AppCoordinator {
    
    // MARK: - Properties}
    
    /// Router
    private let router: Router
    
    /// A reference to the root app window.
    private var window: UIWindow?
    
    /// Example coordinator for a tab
    private let exampleTabCoordinator: ExampleTabCoordinator
    
    // MARK: - Navigation Stack
    
    /// Root view controller
    private(set) lazy var rootViewController: UITabBarController = {
        let tabBarController = UITabBarController()
        
        // Setup tabs
        tabBarController.viewControllers = [
            exampleTabCoordinator.navigationController
        ]
        
        return tabBarController
    }()
    
    // MARK: - Methods
    
    /// Constructor. Configure dependencies.
    init(_ window: UIWindow?,
         _ router: Router,
         _ exampleTabCoordinator: ExampleTabCoordinator
        ) {
        self.window = window
        self.router = router
        self.exampleTabCoordinator = exampleTabCoordinator
    }
    
    /// Start the coordinator
    func start() {
        window?.rootViewController = rootViewController
        window?.makeKeyAndVisible()
        
        // Do anything else here.
        demo(withDelay: 2.5)
    }
    
    // MARK: - Implementation
    
    /// This is an example method that performs a transition demo
    private func demo(withDelay delay: TimeInterval) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            self.router.navigate(to: .exampleModal) { _ in
                
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    self.router.navigate(to: .exampleDetail(withID: "Example"))
                }
            }
        }
    }
    
}
