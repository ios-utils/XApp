//
//  ExampleDetailViewModel
//

import Foundation

/**
 Example Detail View Model
 
 An example detail view model.
 */
class ExampleDetailViewModel {
    
    /// Example model
    var exampleModel: ExampleModel!
    
}
