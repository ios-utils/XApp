//
//  Router
//

import XRouter

/**
 Router
 
 An appliance that allows you to trigger flows and navigate straight to
 statically declared destinations in just one line:
 
 Basic Usage:
 ```
 router.navigate(to: .votingBooth)
 ```
 */
public class Router: XRouter<Route> {
    
    /// Prepare the route destinations.
    override public func prepareForTransition(to route: Route) throws -> UIViewController {
        switch route {
        case .votingBooth: return container.resolve(AppCoordinator.self)!.goToVotingBooth()
        }
    }
    
    /// Log unhandled routing errors.
    override public func received(unhandledError error: Error) {
        log.error("Routing error occured. Error: \(error.localizedDescription)")
    }

}
