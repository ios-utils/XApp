//
//  Router
//

import XRouter

/**
 Router
 
 An appliance that allows you to trigger flows and navigate straight to
 statically declared destinations in just one line:
 
 ```
 router.navigate(to: .profile(withID: 23))
 ```
 */
class Router: XRouter<Route> {
    
    /// Prepare the route destinations.
    override func prepareForTransition(to route: Route) throws -> UIViewController {
        switch route {
        case .exampleTabHome:
            return container.resolve(ExampleTabCoordinator.self)!.gotoHome()
        case .exampleModal:
            return container.resolve(ExampleModalCoordinator.self)!.start()
        case .exampleDetail(let identifier):
            return container.resolve(ExampleDetailViewController.self, argument: identifier)!
        }
    }
    
    /// Log unhandled routing errors.
    override func received(unhandledError error: Error) {
        log.error("Routing error occured. Error: \(error.localizedDescription)")
    }

}
