//
//  Dependency Injection Container
//

import UIKit
import Swinject
import SwinjectAutoregistration

/**
 Depdendency Injection Container. Powered by Swinject.
 - Documentation available at: https://github.com/Swinject/Swinject
 - Checkout the autoregistration docs here: https://github.com/Swinject/SwinjectAutoregistration
 
 Register your class registrations here.
 */
extension Container {
    
    /// Create the dependency container.
    static func create() -> Container {
        let container = Container()
        container.registerCoordinators()
        container.registerViewControllers()
        container.registerViewModels()
        container.registerUtilities()
        return container
    }
    
    // MARK: - Registrations
    
    /// Coordinators
    private func registerCoordinators() {
        autoregister(AppCoordinator.self,
                     argument: Optional<UIWindow>.self,
                     initializer: AppCoordinator.init)
            .inObjectScope(.container)
        
        autoregister(ExampleModalCoordinator.self,
                     initializer: ExampleModalCoordinator.init)
            .inObjectScope(.container)
        
        autoregister(ExampleTabCoordinator.self,
                     initializer: ExampleTabCoordinator.init)
            .inObjectScope(.container)
    }
    
    /// View controllers
    private func registerViewControllers() {
        register(ExampleDetailViewController.self) { (resolver, identifier: String) in
            let viewController = ExampleDetailViewController()
            viewController.viewModel = resolver.resolve(ExampleDetailViewModel.self, argument: identifier)
            return viewController
        }
    }
    
    /// View models
    private func registerViewModels() {
        register(ExampleDetailViewModel.self) { (_, identifier: String) in
            let viewModel = ExampleDetailViewModel()
            viewModel.exampleModel = ExampleModel(identifier: identifier)
            return viewModel
        }
    }
    
    /// Utilities
    private func registerUtilities() {
        autoregister(Router.self, initializer: Router.init)
            .inObjectScope(.container)
    }
    
}
