//
//  AppDelegate
//

import UIKit

/**
 AppDelegate
 
 The app delegate works alongside the app object to ensure your app
  interacts properly with the system and with other apps.
 */
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    // MARK: - Properties

    /// Main application window
    lazy var window: UIWindow? = UIWindow(frame: UIScreen.main.bounds)
    
    /// Main coordinator
    lazy var appCoordinator: AppCoordinator! = container.resolve(AppCoordinator.self, argument: window)
    
    // MARK: - UIApplicationDelegate
    
    /// Override point for customization after application launch.
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        appCoordinator.start()
        return true
    }

}
