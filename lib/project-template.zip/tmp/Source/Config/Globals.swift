//
//  Globals
//

import SwiftyBeaver
import Swinject

/**
 Global container
 */
let container = Container.create()

/**
 Logging.
 Powered by SwiftyBeaver.
 Docs: https://github.com/SwiftyBeaver/SwiftyBeaver
 */
let log: SwiftyBeaver.Type = {
    let log = SwiftyBeaver.self
    
    // Configure loggers here...
    log.addDestination(ConsoleDestination())
    
    return log
}()

/**
 Static-typed and compile time checked resources.
 Powered by R.swift.
 Docs: https://github.com/mac-cain13/R.swift
 */

/// Colors shortcut
typealias Colors = R.color

/// Localized strings shortcut
typealias Strings = R.string.localizable
