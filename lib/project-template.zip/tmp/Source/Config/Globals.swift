//
//  Globals
//

import SwiftyBeaver
import Swinject

/**
 Global
 */
let container = Container.create()

/**
 Powerful logging. Powered by SwiftyBeaver.
 Docs: https://github.com/SwiftyBeaver/SwiftyBeaver
 */
let log: SwiftyBeaver.Type = {
    let log = SwiftyBeaver.self
    
    // Configure loggers here...
    log.addDestination(ConsoleDestination())
    
    return log
}()

/**
 Great strong-type resources. Powered by R.swift.
 Documentation available at: https://github.com/mac-cain13/R.swift
 */
typealias LocalizedStrings = R.string.localizable
