//
//  Routes
//

import XRouter

/**
 App Routes
 
 Define your application routes here, and configure their destinations in `Router`.
 */
enum Route: RouteType {
    
    /// Example tab home
    case exampleTabHome
    
    /// Example modal screen
    case exampleModal
    
    /// Example detail screen
    case exampleDetail(withID: String)
    
    // Add routes here...
    
}
