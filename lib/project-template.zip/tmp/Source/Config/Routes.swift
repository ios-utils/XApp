//
//  Routes
//

import XRouter

/**
 App Routes
 
 Define your App's routes here, and configure them in `Router`.
 */
public enum Route: RouteType {
    
    /// Voting booth
    case votingBooth
    
    // Add routes...
    
}
