//
//  AppCoordinator
//

import UIKit

/**
 Main App Coordinator.
 */
public class AppCoordinator {
    
    // MARK: - Properties
    
    /// Router
    private let router: Router
    
    /// A reference to the root app window.
    private var window: UIWindow?
    
    // MARK: - Navigation Stack
    
    /// Root view controller
    private(set) lazy var rootViewController = UINavigationController()
    
    // MARK: - Methods
    
    /// Constructor. Configure dependencies.
    public init(window: UIWindow?, router: Router) {
        self.window = window
        self.router = router
    }
    
    /// Start the coordinator
    public func start() {
        window?.rootViewController = goToVotingBooth()
        window?.makeKeyAndVisible()
    }
    
    /// Go to voting booth
    public func goToVotingBooth() -> UINavigationController {
        let votingBoothViewController: VotingBoothViewController! = container.resolve(VotingBoothViewController.self)
        rootViewController.setViewControllers([votingBoothViewController], animated: true)
        return rootViewController
    }
    
}
