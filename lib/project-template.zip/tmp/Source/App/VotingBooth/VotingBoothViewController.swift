//
//  VotingBoothViewController
//  App
//

import RxSwift
import RxCocoa

/**
 Voting booth view controller.
 
 - Note: Ideally these container/button pairs would be one component
         that managed themselves - but the logic's pretty simple and
         there's only two, so here we have some slight duplication.
 */
public final class VotingBoothViewController: UIViewController, NibInstantiable {
    
    // MARK: - IBOutlets
    
    /// Option A Container
    @IBOutlet weak var optionAContainer: CardView!
    
    /// Option B Container
    @IBOutlet weak var optionBContainer: CardView!
    
    /// Option A Button
    @IBOutlet weak var optionAButton: UIButton!
    
    /// Option B Button
    @IBOutlet weak var optionBButton: UIButton!
    
    /// Option A Label
    @IBOutlet weak var optionALabel: UILabel!
    
    /// Option B Label
    @IBOutlet weak var optionBLabel: UILabel!
    
    // MARK: - Properties
    
    /// Haptic feedback
    private let feedbackGenerator = UISelectionFeedbackGenerator()
    
    /// Dispose bag
    private let disposeBag = DisposeBag()
    
    /// Provider
    private let provider: QuoteProvider! = container.resolve(QuoteProvider.self)
    
    // MARK: - UIViewController
    
    /// View will load
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        configureView()
        loadNewQuoteA()
        loadNewQuoteB()
    }
    
    /// View will appear
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.setNavigationBarHidden(true, animated: false)
        feedbackGenerator.prepare()
    }
    
    // MARK: - Actions
    
    /// Handle tapped option A
    @IBAction func tappedOptionA(_ sender: Any) {
        feedbackGenerator.selectionChanged()
        optionAContainer.backgroundColor = Colors.lightBlue()
        optionBContainer.backgroundColor = .white
        loadNewQuoteB()
        feedbackGenerator.prepare()
    }
    
    /// Handle tapped option B
    @IBAction func tappedOptionB(_ sender: Any) {
        feedbackGenerator.selectionChanged()
        optionAContainer.backgroundColor = .white
        optionBContainer.backgroundColor = Colors.lightBlue()
        loadNewQuoteA()
        feedbackGenerator.prepare()
    }
    
    // MARK: - Implementation
    
    /// Setup the initial view
    private func configureView() {
        optionALabel.text = Strings.boxATitle()
        optionBLabel.text = Strings.boxBTitle()
    }
    
    /// Load a quote A
    private func loadNewQuoteA() {
        optionAButton.setTitle("...", for: .normal)
        
        provider.getRandomQuote()
            .subscribe(onSuccess: updateOptionAText,
                       onError: { log.error($0) })
            .disposed(by: disposeBag)
    }
    
    /// Update quote B
    private func loadNewQuoteB() {
        optionBButton.setTitle("...", for: .normal)
        
        provider.getRandomQuote()
            .subscribe(onSuccess: updateOptionBText,
                       onError: { log.error($0) })
            .disposed(by: disposeBag)
    }
    
    /// Update option A text
    private func updateOptionAText(_ title: String) {
        optionAButton.setTitle(title, for: .normal)
    }
    
    /// Update option B text
    private func updateOptionBText(_ title: String) {
        optionBButton.setTitle(title, for: .normal)
    }
    
}
