//
//  ExampleModel
//

import Foundation

/**
 Example Model
 */
struct ExampleModel {
    
    /// Identifier
    let identifier: String
    
}
